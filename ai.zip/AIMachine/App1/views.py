from django.shortcuts import render,redirect
from .forms import DataForm
from .models import Customers
from django.contrib import messages
from django.http import JsonResponse

# Create your views here.
def index(request):
    if request.method=='POST':
        form=DataForm(request.POST)
        
        if  form.is_valid():
            form.save()
            messages.success(request,"Successfully")
            form=DataForm()
            return render(request,'index.html',{'form':form})
            #return redirect('index')
        else:
            messages.error(request,'All fields are required')
            return render(request,'index.html',{'form':form})
            
    else:
        form=DataForm()
        context={
            'form':form,
        }
        return render(request,'index.html',context)

def data(request):
    statistics=Customers.objects.all()
    return render (request,'data.html',{'data':statistics})

def customer_chart_data(request):
    labels = ["East", "Midwest","Northeast","Central"]
    values = [
        Customers.objects.filter(Region=1).count(),
        Customers.objects.filter(Region=2).count(),
        Customers.objects.filter(Region=3).count(),
        Customers.objects.filter(Region=4).count()
    ]
    #return render(request,'index.html',{"labels": labels, "values": values})
    
    return JsonResponse({"labels": labels, "values": values})