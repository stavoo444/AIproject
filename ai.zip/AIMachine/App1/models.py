from django.db import models
from sklearn.tree import DecisionTreeClassifier
import joblib

# Create your models here.
LOCATION=(
    (1,'Urban'),
    (2,'Rural'),
)

STATE=(
    (1,'Dodoma'),
    (2,'Kigoma'),
    (3,'Iringa'),
    (4,'Mwanza'),
    (5,'Dar es salaam'),
    (6,'Arusha'),
    (7,'Kilimanjaro'),
)

REGION=(
    (1,'East'),
    (2,'Midwest'),
    (3,'Northeast'),
    (4,'Central'),
)

CONSTRUCTION=(
    (1,'Frame'),
    (2,'Fire Resist'),
    (3,'Masonry'),
    (4,'Metal Clad'),

)



class Customers(models.Model):
    Email=models.CharField(max_length=100,unique=True)
    State=models.PositiveIntegerField(choices=STATE)
    Location=models.PositiveIntegerField(choices=LOCATION)
    Region=models.PositiveIntegerField(choices=REGION)
    Investment=models.PositiveIntegerField()
    Construction=models.PositiveIntegerField(choices=CONSTRUCTION)
    BusinessType=models.CharField(max_length=100,blank=True)
    Date=models.DateTimeField(auto_now_add=True)
    
    
    def save(self,*agrs,**kwargs):
        ml_model=joblib.load('model/my_model.joblib')
        self.BusinessType=ml_model.predict([[self.Location,self.State,
                                    self.Region,
                                    self.Investment,self.Construction]])
        return super().save(*agrs,**kwargs)
    class Meta:
        ordering=['-Date']
        
    def __str__(self):
        return self.Email

