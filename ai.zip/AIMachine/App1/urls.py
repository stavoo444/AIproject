from django.urls import path
from . import views

urlpatterns = [
    path('',views.index,name="index"),
    path('prediction/',views.data,name="data"),
    path("customer-chart-data/", views.customer_chart_data, name="customer_chart_data"),
    
]
