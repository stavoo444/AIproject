from django.contrib import admin
from . import models
from .models import Customers
# Register your models here.

class CustomerAdmin(admin.ModelAdmin):
    list_per_page=5
    list_max_show_all=5
    list_display=('Email','Location','State','Region','Investment','Date','BusinessType',)
admin.site.register(models.Customers,CustomerAdmin)
